package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun DotDayTheme(
    accentColor: Color = PrimaryNavy,
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = darkColorScheme(
        primary = PrimaryNavy,
        onPrimary = AccentForeground,
        primaryContainer = PrimaryNavy,
        onPrimaryContainer = AccentForeground,
        secondary = TextSecondary,
        onSecondary = TextPrimary,
        background = Background,
        onBackground = TextPrimary,
        surface = SurfacePrimary,
        onSurface = TextPrimary,
        surfaceVariant = ElevatedSurface,
        onSurfaceVariant = TextSecondary,
        outline = OutlineMuted
    )

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
