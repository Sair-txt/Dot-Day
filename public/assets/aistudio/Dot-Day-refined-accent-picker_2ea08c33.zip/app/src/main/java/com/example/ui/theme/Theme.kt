package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance

@Composable
fun DotDayTheme(
    accentColor: Color = PrimaryNavy,
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    // The user-selected accent is the actual Material primary, not just a parameter passed
    // through the screens. Choose foreground contrast based on its luminance so light accents
    // remain readable on buttons and selected controls.
    val accentForeground = if (accentColor.luminance() > 0.46f) Color(0xFF111216) else Color.White
    val colorScheme = darkColorScheme(
        primary = accentColor,
        onPrimary = accentForeground,
        primaryContainer = accentColor,
        onPrimaryContainer = accentForeground,
        secondary = TextSecondary,
        onSecondary = TextPrimary,
        background = Background,
        onBackground = TextPrimary,
        surface = SurfacePrimary,
        onSurface = TextPrimary,
        surfaceVariant = ElevatedSurface,
        onSurfaceVariant = TextSecondary,
        outline = OutlineMuted
    )

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
