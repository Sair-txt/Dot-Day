package com.example.ui.settings

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.GridDensity
import com.example.data.model.UserSettings
import com.example.data.model.WidgetBackgroundMode
import com.example.ui.theme.DeepCharcoal
import com.example.ui.theme.ElevatedSurface
import com.example.ui.theme.OutlineMuted
import com.example.ui.theme.PrimaryNavy
import com.example.ui.theme.PrimaryNavyLight
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary

@Composable
fun SettingsScreen(
    settings: UserSettings,
    accentColor: Color,
    onAccentChanged: (String) -> Unit,
    onCountTodayChanged: (Boolean) -> Unit,
    onDensityChanged: (GridDensity) -> Unit,
    onWidgetBackgroundModeChanged: (WidgetBackgroundMode) -> Unit,
    onWidgetBackgroundOpacityChanged: (Int) -> Unit,
    onSyncWidget: () -> Unit,
    onSeedSamples: () -> Unit,
    modifier: Modifier = Modifier
) {
    var widgetSyncedMessage by remember { mutableStateOf(false) }
    var draftWidgetOpacity by remember(settings.widgetBackgroundOpacity) {
        mutableStateOf(settings.widgetBackgroundOpacity.toFloat())
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DeepCharcoal)
            .testTag("settings_screen"),
        contentPadding = PaddingValues(bottom = 110.dp, top = 16.dp, start = 16.dp, end = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Title
        item {
            Column(modifier = Modifier.padding(bottom = 8.dp)) {
                Text(
                    text = "SETTINGS",
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Personalize colors, grid, and home-screen widget",
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        // Section: Accent Color
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, OutlineMuted),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Palette,
                            contentDescription = null,
                            tint = TextPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Dot Accent Color",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Highlights countdowns and selected accents; year-day dots keep the neutral palette.",
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodySmall
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        UserSettings.PRESET_ACCENTS.forEach { (hex, name) ->
                            val color = Color(android.graphics.Color.parseColor(hex))
                            val isSelected = settings.accentHex.equals(hex, ignoreCase = true)
                            val isDarkNavy = hex.equals("#191F45", ignoreCase = true)

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (isSelected) ElevatedSurface else Color.Transparent)
                                    .border(
                                        1.dp,
                                        if (isSelected) {
                                            if (isDarkNavy) PrimaryNavyLight else color.copy(alpha = 0.6f)
                                        } else Color.Transparent,
                                        RoundedCornerShape(12.dp)
                                    )
                                    .clickable { onAccentChanged(hex) }
                                    .padding(horizontal = 14.dp, vertical = 10.dp)
                                    .testTag("select_color_$hex"),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(22.dp)
                                            .clip(CircleShape)
                                            .background(color)
                                            .border(
                                                1.dp,
                                                if (isDarkNavy) PrimaryNavyLight else Color.Transparent,
                                                CircleShape
                                            )
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = name,
                                        color = TextPrimary,
                                        fontSize = 14.sp,
                                        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                                    )
                                }

                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Selected",
                                        tint = if (isDarkNavy) Color.White else color,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Section: Grid Spacing / Density
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, OutlineMuted),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Year Grid Density",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Adjust the columns and size of dots on the main Year Canvas.",
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodySmall
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(ElevatedSurface)
                            .border(1.dp, OutlineMuted, RoundedCornerShape(12.dp))
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        GridDensity.values().forEach { density ->
                            val isSelected = settings.gridDensity == density
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isSelected) PrimaryNavy else Color.Transparent)
                                    .then(
                                        if (isSelected) Modifier.border(1.dp, PrimaryNavyLight, RoundedCornerShape(10.dp))
                                        else Modifier
                                    )
                                    .clickable { onDensityChanged(density) }
                                    .padding(vertical = 8.dp)
                                    .testTag("density_${density.name.lowercase()}"),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = density.label,
                                    color = if (isSelected) TextPrimary else TextSecondary,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 11.5.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Section: Calculation Preferences
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, OutlineMuted),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Day Count Calculation",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                            Text(
                                text = "Count today as remaining",
                                color = TextPrimary,
                                fontWeight = FontWeight.Medium,
                                fontSize = 14.sp
                            )
                            Text(
                                text = if (settings.countTodayAsRemaining)
                                    "Remaining includes today through Dec 31."
                                else
                                    "Remaining counts only days strictly after today.",
                                color = TextTertiary,
                                fontSize = 12.sp
                            )
                        }

                        Switch(
                            checked = settings.countTodayAsRemaining,
                            onCheckedChange = { onCountTodayChanged(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = PrimaryNavyLight,
                                uncheckedThumbColor = TextSecondary,
                                uncheckedTrackColor = ElevatedSurface
                            ),
                            modifier = Modifier.testTag("switch_count_today")
                        )
                    }
                }
            }
        }

        // Section: Widget appearance
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, OutlineMuted),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Widget Appearance",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Preview and choose how the year grid sits on your home screen.",
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        WidgetAppearanceOption(
                            mode = WidgetBackgroundMode.SOLID,
                            opacity = draftWidgetOpacity.toInt(),
                            selected = settings.widgetBackgroundMode == WidgetBackgroundMode.SOLID,
                            onClick = { onWidgetBackgroundModeChanged(WidgetBackgroundMode.SOLID) },
                            modifier = Modifier.weight(1f)
                        )
                        WidgetAppearanceOption(
                            mode = WidgetBackgroundMode.TRANSPARENT,
                            opacity = draftWidgetOpacity.toInt(),
                            selected = settings.widgetBackgroundMode == WidgetBackgroundMode.TRANSPARENT,
                            onClick = { onWidgetBackgroundModeChanged(WidgetBackgroundMode.TRANSPARENT) },
                            modifier = Modifier.weight(1f)
                        )
                        WidgetAppearanceOption(
                            mode = WidgetBackgroundMode.TRANSLUCENT,
                            opacity = draftWidgetOpacity.toInt(),
                            selected = settings.widgetBackgroundMode == WidgetBackgroundMode.TRANSLUCENT,
                            onClick = { onWidgetBackgroundModeChanged(WidgetBackgroundMode.TRANSLUCENT) },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    if (settings.widgetBackgroundMode == WidgetBackgroundMode.TRANSLUCENT) {
                        Spacer(modifier = Modifier.height(18.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Background opacity",
                                color = TextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "${draftWidgetOpacity.toInt()}%",
                                color = TextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.testTag("widget_bg_opacity_value")
                            )
                        }
                        Slider(
                            value = draftWidgetOpacity,
                            onValueChange = { draftWidgetOpacity = it.toInt().toFloat() },
                            onValueChangeFinished = {
                                onWidgetBackgroundOpacityChanged(draftWidgetOpacity.toInt().coerceIn(0, 100))
                            },
                            valueRange = 0f..100f,
                            steps = 99,
                            modifier = Modifier.testTag("widget_bg_opacity_slider")
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Wallpaper visible", color = TextTertiary, fontSize = 11.sp)
                            Text("Opaque charcoal", color = TextTertiary, fontSize = 11.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "This is a translucent charcoal tint, not a live blur: Jetpack Glance cannot blur the wallpaper behind a widget. Transparent mode works best on darker wallpaper; choose translucent or solid on bright backgrounds for readable text.",
                        color = TextTertiary,
                        style = MaterialTheme.typography.bodySmall,
                        lineHeight = 17.sp
                    )
                }
            }
        }

        // Section: Home Screen Widget
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, OutlineMuted),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Widgets,
                            contentDescription = null,
                            tint = TextPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Landscape 4 × 2 Home-Screen Widget",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Dot Day includes a native Jetpack Glance widget designed for a 4 × 2 landscape footprint:",
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "1. Long-press an empty area on your Android home screen.\n2. Open Widgets.\n3. Find Dot Day and drag the widget onto your home screen.\n4. The widget shows the complete year dot grid and the days left count.",
                        color = TextTertiary,
                        style = MaterialTheme.typography.bodySmall,
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            onSyncWidget()
                            widgetSyncedMessage = true
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = PrimaryNavy,
                            contentColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, PrimaryNavyLight),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("sync_widget_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (widgetSyncedMessage) "Widget Synced!" else "Refresh Widget Now")
                    }
                }
            }
        }

        // Section: Data & Backup
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, OutlineMuted),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = TextPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Privacy & Local Data",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Dot Day operates 100% offline. All events and preferences are persisted locally on your device with Room and SharedPreferences. No remote accounts, analytics, or background telemetry.",
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodySmall,
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = onSeedSamples,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ElevatedSurface,
                            contentColor = TextPrimary
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, OutlineMuted),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("seed_sample_events_button")
                    ) {
                        Text("Add Sample Countdowns (Birthdays & Holidays)")
                    }
                }
            }
        }

        // Footer version info
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Dot Day v1.0",
                    color = TextTertiary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Minimalist Time & Countdown Visualizer",
                    color = TextTertiary.copy(alpha = 0.7f),
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
private fun WidgetAppearanceOption(
    mode: WidgetBackgroundMode,
    opacity: Int,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(12.dp)
    val label = when (mode) {
        WidgetBackgroundMode.SOLID -> "Solid"
        WidgetBackgroundMode.TRANSPARENT -> "Transparent"
        WidgetBackgroundMode.TRANSLUCENT -> "Translucent"
    }
    Column(
        modifier = modifier
            .clip(shape)
            .background(ElevatedSurface)
            .border(
                width = if (selected) 1.5.dp else 1.dp,
                color = if (selected) PrimaryNavyLight else OutlineMuted,
                shape = shape
            )
            .clickable(onClick = onClick)
            .padding(6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        WidgetAppearancePreview(mode = mode, opacity = opacity)
        Spacer(modifier = Modifier.height(7.dp))
        Text(
            text = label,
            color = if (selected) TextPrimary else TextSecondary,
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium
        )
    }
}

@Composable
private fun WidgetAppearancePreview(
    mode: WidgetBackgroundMode,
    opacity: Int
) {
    val shape = RoundedCornerShape(8.dp)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(76.dp)
            .clip(shape)
            .border(1.dp, OutlineMuted, shape)
    ) {
        // This patterned layer is the simulated launcher wallpaper. The Transparent preview
        // paints no widget surface over it; the app widget itself follows the same rule.
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawRect(Color(0xFF383940))
            drawRect(
                color = Color(0xFF202126),
                topLeft = Offset(size.width * 0.58f, 0f),
                size = Size(size.width * 0.42f, size.height)
            )
            drawRect(
                color = Color(0xFF2B2C33),
                topLeft = Offset(0f, size.height * 0.68f),
                size = Size(size.width * 0.58f, size.height * 0.32f)
            )
        }

        if (mode != WidgetBackgroundMode.TRANSPARENT) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        if (mode == WidgetBackgroundMode.SOLID) {
                            Color(0xFF202126)
                        } else {
                            Color(0xFF202126).copy(alpha = opacity.coerceIn(0, 100) / 100f)
                        }
                    )
                    .then(
                        if (mode == WidgetBackgroundMode.TRANSLUCENT) {
                            Modifier.border(1.dp, Color.White.copy(alpha = 0.12f), shape)
                        } else Modifier
                    )
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 7.dp, vertical = 6.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("2026", color = TextPrimary, fontSize = 8.sp, fontWeight = FontWeight.Medium)
                Spacer(modifier = Modifier.weight(1f))
                Text("72 DAYS LEFT", color = TextPrimary, fontSize = 7.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(5.dp))
            Canvas(modifier = Modifier.fillMaxWidth().weight(1f)) {
                val columns = 19
                val rows = 5
                val stepX = size.width / columns
                val stepY = size.height / rows
                val radius = minOf(stepX, stepY) * 0.31f
                val currentDot = 75
                for (i in 0 until columns * rows) {
                    val x = (i % columns) * stepX + stepX / 2f
                    val y = (i / columns) * stepY + stepY / 2f
                    when {
                        i < currentDot -> {
                            drawCircle(Color(0xFF111216), radius = radius + 0.3f, center = Offset(x, y))
                            drawCircle(Color(0xFFF5F5F7), radius = radius, center = Offset(x, y))
                        }
                        i == currentDot -> {
                            drawCircle(Color(0xFFF5F5F7), radius = radius + 0.55f, center = Offset(x, y), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 0.8f))
                            drawCircle(Color(0xFF191F45), radius = radius * 0.72f, center = Offset(x, y))
                        }
                        else -> drawCircle(Color(0xFF3D3E45), radius = radius, center = Offset(x, y))
                    }
                }
            }
        }
    }
}

